<?php
$servername = "localhost"; 
$username = "root"; 
$password = ""; 
$dbname = "Proyectos"; // Asegúrate de poner el nombre correcto de tu base de datos

// Crear la conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}
// Verificar si se ha enviado el formulario de inserción de nuevo proyecto
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Obtener los datos del formulario
    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];
    $imagen = $_POST['imagen'];
    $fecha = $_POST['fecha'];

    // Insertar el nuevo proyecto en la base de datos
    $sql = "INSERT INTO proyectos (nombre, descripcion, imagen, fecha) VALUES ('$nombre', '$descripcion', '$imagen', '$fecha')";
    
    if ($conn->query($sql) === TRUE) {
        echo "Nuevo proyecto añadido correctamente.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

















// Consulta para obtener los proyectos existentes
$sql = "SELECT * FROM proyectos"; // Cambia 'proyectos' por el nombre de tu tabla
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mi página</title>

    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>

    <!-- Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap" rel="stylesheet">

    <!-- Custom CSS -->
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f4f7f6;
            color: #333;
            padding-bottom: 100px; /* Espacio para el footer */
            display: flex;
            flex-direction: column;
            min-height: 100vh; /* Asegura que el body ocupe al menos toda la altura de la ventana */
        }

        .content {
            flex: 1; /* Permite que el contenido ocupe el espacio disponible */
        }

        .navbar {
            background-color: #343a40;
        }

        .navbar-brand, .nav-link {
            color: #fff !important;
        }

        .header {
            background-color: #17a2b8;
            color: white;
            padding: 80px 0;
            text-align: center;
        }

        .header h1 {
            font-weight: 700;
            margin-bottom: 20px;
            animation: fadeInDown 1.5s ease;
        }

        .header p {
            font-size: 1.2rem;
            animation: fadeInUp 1.5s ease;
        }

        .card {
            transition: transform 0.3s ease;
        }

        .card:hover {
            transform: translateY(-10px);
        }

        .btn-primary {
            background-color: #17a2b8;
            border-color: #17a2b8;
        }

        .btn-primary:hover {
            background-color: #138f9c;
            border-color: #138f9c;
        }

        .section-title {
            margin: 40px 0;
            text-align: center;
            font-weight: 700;
            font-size: 2rem;
        }

        /* Footer */
        .footer {
            background-color: #343a40;
            color: white;
            padding: 20px 0;
            text-align: center;
        }

        /* Animations */
        @keyframes fadeInDown {
            0% { opacity: 0; transform: translateY(-20px); }
            100% { opacity: 1; transform: translateY(0); }
        }

        @keyframes fadeInUp {
            0% { opacity: 0; transform: translateY(20px); }
            100% { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top">
        <div class="container">
            <a class="navbar-brand" href="#">Proyecto Izan De Dios</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="#proyectos">Mis Proyectos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#contacto">Contacto</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="content">
        <!-- Header Section -->
        <header class="header">
            <div class="container">
                <h1>Más Sobre Mí</h1>
                <!-- Carta de Visita -->
<section class="container my-5">
    <div class="row">
        <div class="col-md-8 offset-md-2">
            <h2 class="section-title">Sobre mí</h2>
            <p>
                ¡Hola! Soy Izan De Dios, actualmente estudiante de 2º ASIR (Administración de Sistemas Informáticos en Red). 
                A lo largo de mis estudios, me he especializado en el manejo de servidores, redes y algo de programación. Además, tengo un interés especial por el diseño web y la programación, 
                lo que me ha permitido trabajar en proyectos innovadores.
            </p>
            <p>
                He tenido la oportunidad de estudiar en el Centro Cuatrovientos, donde he desarrollado diversas habilidades 
                técnicas y participé en programas como Erasmus+, realizando prácticas en Oporto. Además, disfruto trabajando 
                en proyectos que combinan tecnología y creatividad, como el desarrollo de aplicaciones web y dispositivos 
                con Arduino para ayudar a personas con discapacidad.
            </p>
            <p>
                Me apasiona seguir aprendiendo y aplicar mis conocimientos en soluciones reales. Si quieres saber más sobre 
                mis proyectos o contactarme, no dudes en explorar mi página web.
            </p>
        </div>
    </div>
</section>

                <p>Explora mis proyectos y contáctame para más información.</p>
            </div>
        </header>

        <!-- Buscador de proyectos -->
        <div class="container my-4">
            <input type="text" id="buscador" class="form-control" placeholder="Buscar proyectos">
        </div>

        <!-- Proyectos Section -->
        <section id="proyectos" class="container my-5">
            <h2 class="section-title">Proyectos</h2>
            <div class="row">
                <div class="col-md-4 mb-4 proyecto">
                    <div class="card">
                        <img src="./img/28_visitar-Porto-1200x630 (1).jpg" class="card-img-top" alt="Proyecto 1">
                        <div class="card-body">
                            <h5 class="card-title">Erasmus +</h5>
                            <p class="card-text">Participante en Erasmus +. Prácticas en Oporto.</p>
                            <button class="btn btn-primary" data-toggle="modal" data-target="#modal1">Ver más</button>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4 proyecto">
                    <div class="card">
                        <img src="./img/reduccion_emisiones_co2 (1).png" class="card-img-top" alt="Proyecto 2">
                        <div class="card-body">
                            <h5 class="card-title">Reducción CO2 Pamplona</h5>
                            <p class="card-text">Proyecto reducción de la huella de carbono.</p>
                            <button class="btn btn-primary" data-toggle="modal" data-target="#modal2">Ver más</button>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4 proyecto">
                    <div class="card">
                        <img src="./img/burlada.jpg" class="card-img-top" alt="Proyecto 4">
                        <div class="card-body">
                            <h5 class="card-title">Centro de mayores Burlada</h5>
                            <p class="card-text">Clases en centro de mayores Burlada.</p>
                            <button class="btn btn-primary" data-toggle="modal" data-target="#modal4">Ver más</button>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4 proyecto">
                    <div class="card">
                        <img src="./img/i3.jpg" class="card-img-top" alt="Proyecto 3">
                        <div class="card-body">
                            <h5 class="card-title">I3</h5>
                            <p class="card-text">Desarrollo de dispositivo de ayuda para personas con discapacidad con Arduino.</p>
                            <button class="btn btn-primary" data-toggle="modal" data-target="#modal3">Ver más</button>
                        </div>
                    </div>
                </div>
            </div>
        


    
        <?php
            
            if ($result->num_rows > 0) {
                
                while ($row = $result->fetch_assoc()) {
                    echo '<div class="col-md-4 mb-4 proyecto">';
                    echo '<div class="card">';
                    echo '<img src="' . $row['imagen'] . '" class="card-img-top" alt="' . $row['nombre'] . '">';
                    echo '<div class="card-body">';
                    echo '<h5 class="card-title">' . $row['nombre'] . '</h5>';
                    echo '<p class="card-text">' . $row['descripcion'] . '</p>';
                    echo '<p class="text-muted">Fecha: ' . $row['fecha'] . '</p>';
                    echo '<button class="btn btn-primary" data-toggle="modal" data-target="#modal' . $row['id'] . '">Ver más</button>';
                    echo '</div>';
                    echo '</div>';
                    echo '</div>';
                }
            } else {
                echo '<p>No hay proyectos disponibles.</p>';
            }
            ?>
        </div>
    </section>

    
    <?php

    $result->data_seek(0); 
    while ($row = $result->fetch_assoc()) {
        echo '<div class="modal fade" id="modal' . $row['id'] . '" tabindex="-1" aria-labelledby="modalLabel' . $row['id'] . '" aria-hidden="true">';
        echo '<div class="modal-dialog">';
        echo '<div class="modal-content">';
        echo '<div class="modal-header">';
        echo '<h5 class="modal-title" id="modalLabel' . $row['id'] . '">' . $row['nombre'] . '</h5>';
        echo '<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>';
        echo '</div>';
        echo '<div class="modal-body">';
        echo '<img src="' . $row['imagen'] . '" class="img-fluid mb-3" alt="' . $row['nombre'] . '">';
        echo '<p>' . $row['descripcion'] . '</p>';
        echo '<p><strong>Fecha:</strong> ' . $row['fecha'] . '</p>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
    }
    ?>
</section>

           
        </section>
        
        

        <!-- Modales de información de los proyectos -->
        <div class="modal fade" id="modal1" tabindex="-1" role="dialog" aria-labelledby="modal1Label" aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="modal1Label">Más sobre Erasmus +</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <p>Durante mis estudios en el grado medio de SMR en el centro cuatrovientos, se me dio la oportunidad de participar en un erasmus de 3 semanas en Oporto con la finalidad d
                            realizar 3 semanas de FCT en otro pais. Yo junto a uno de mi clase despues de pensarlo muy bien nos apuntamos a esta experiendia. En Oporto, tuve la suerte de realizar mis FCTs
                            en una pequeña tienda de reparacion de todo tipo de dispositivos y software. Ademas, haciamos mantenimientos y limpiezas de estos e incluso dabamos consejos a los cleintes a la hora de 
                            ayudarles a decidirse por uno de nuestros productos, ya que, tambien se vendian moviles, tablets, ordenadores... en mi tienda.</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="modal2" tabindex="-1" role="dialog" aria-labelledby="modal2Label" aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="modal2Label">Más sobre Reducción CO2</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <p>En el curso 1º SMR en el centro cuatrovientos, tuve la oportunidad de crear una pequeña aplicacion para movil con objetivo de ayudar a la ciudad de pamplona a reducir las emisiones de co2. Para esto creamos una aplicacion muy 
                            sencilla. La aplicacion que creamos, calculaba las emisiones que emitia una persona recogiendo datos sobre ella. Para esto, la app preguntaba datos como: ¿Como vienes al centro?, ¿Cuanto utilizas el coche?, ¿Reciclas? etc.
                            Por otro lado, mientras todos los datos se recogian, la app calculaba las emisiones. Una vez terminado de recoger informacion en pantalla aparecia el total de las emisiones y una pequeña imagen dependiendo de estas.</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="modal3" tabindex="-1" role="dialog" aria-labelledby="modal3Label" aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="modal3Label">Más sobre I3</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <p>En el curso 1º ASIR uno de los proyectos mas grandes del curso fue la creacion desde 0 de un dispositivo con Arduino, que fera capaz de "algun modo" de ayudar a personas con discapacidad o a personas mayores con algun problema.
                            En la asignatura Fundamentos de Hardware, fuimos poco a poco entendiendo el funcionamiento de la herramienta Arduino IDE y poco a poco con esta fuimos capaz de desarollar 5 productos difernetes capazes de hacer la vida mas sencilla 
                            en algunos ambitos para gente con distintas discapacidades. Mi producto, trataba de una pequeña cajita situada en la mesa del profesor con distintos modos. Era capaz de controlar el tiempo en un examen, medir el volumen en clase, automatizar tareas mediante
                            un cronometro y enviar señales de aviso mediante luz a la hora de realizar tareas. Con esto, nos enfocabamos en personas que se sienten incomodas en el aula con el ruido generado por otros alumnos ademas de ayudar a personas
                            con problemas para concentrarse o para gestionar el tiempo.</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="modal4" tabindex="-1" role="dialog" aria-labelledby="modal1Label" aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="modal1Label">Más sobre Centro de mayores Burlada</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <p>En 2º SMR mis compañeros de clase y yo participamos en un proyecto que trataba de ser "Profesores" para los señores y señoras mayores de edad del centro de mayores de Burlada.
                            2 veces a la semana, nos reuniamos con ellos en el centro y les enseñabamos a utilizar WORD a nivel usuario. Entre los de clase, nos dividiamos el trabajo haciendo que cada dia que ibamos, aprendieran algo nuevo.
                        </p>
                    </div>
                </div>
            </div>
        </div>
     

        <!-- Contacto Section -->
        <section id="contacto" class="container my-5">
            <h2 class="section-title">Contacto</h2>
            <form id="formContacto">
                <div class="form-group">
                    <label for="nombre">Nombre:</label>
                    <input type="text" class="form-control" id="nombre" required>
                </div>
                <div class="form-group">
                    <label for="email">Correo electrónico:</label>
                    <input type="email" class="form-control" id="email" required>
                </div>
                <div class="form-group">
                    <label for="mensaje">Mensaje:</label>
                    <textarea class="form-control" id="mensaje" rows="4" required></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Enviar</button>
            </form>
        </section>

        <!-- Modal de confirmación -->
        <div class="modal fade" id="confirmacionModal" tabindex="-1" role="dialog" aria-labelledby="confirmacionModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="confirmacionModalLabel">Gracias por contactarme!</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <p>Tu mensaje ha sido enviado exitosamente. Me pondre en contacto contigo pronto.</p>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <!-- Footer -->
    <footer class="footer">
        <p>&copy; 2024 Izan De Dios</p>
    </footer>

    <!-- Scripts -->
    <script>
        // Validación del formulario de contacto
        $("#formContacto").on("submit", function (e) {
            e.preventDefault();

            var email = $("#email").val();
            var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

            if (emailRegex.test(email)) {
                // Mostrar el modal de confirmación si el correo es válido
                $("#confirmacionModal").modal("show");
                $("#formContacto")[0].reset(); // Limpiar formulario
            } else {
                alert("Por favor, introduce un correo válido.");
            }
        });

        // Buscador de proyectos
        $("#buscador").on("keyup", function () {
            var filtro = $(this).val().toLowerCase();

            $(".proyecto").filter(function () {
                $(this).toggle($(this).text().toLowerCase().indexOf(filtro) > -1);
            });
        });
    </script>

</body>
</html>
